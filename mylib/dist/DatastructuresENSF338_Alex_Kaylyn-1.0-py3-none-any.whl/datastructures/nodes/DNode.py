
class DNode:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None
